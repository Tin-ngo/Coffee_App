<div id="viewport">

<div class="container-fluid" id="noidung">
      <h4>Database khuyenmai</h4>

  
      <div style="background-color: #e5e5e5; padding: 10px 50px 10px; color:gray;">

        <form action="?action=themkhuyenmai_xl" method="POST">
      	<table border="0" cellpadding="10">
        
            <tr>
               <td>Loại Khuyến mãi:</td>
               <td><input type="text" value="" name="LoaiKM" required></td>
           </tr>
            <tr>
               <td>Giá trị Khuyến mãi (%):</td>
               <td><input type="text" value="" name="GiatriKM" required></td>
           </tr>
            <tr>
               <td>Ngày bắt đầu:</td>
               <td><input type="date" value="" name="NgayBD"></td>
           </tr>
           <tr>
               <td>Ngày kết thúc:</td>
               <td><input type="date" value="" name="NgayKT"></td>
           </tr>
           
           <tr>
           	<td colspan="2"><button  style="width: 100px; background-color: darkgray;" type="submit">Submit</button></td>
           </tr>

        </table>
      </form>
      </div>
     

</div>

</div>