<!DOCTYPE html>
<html>

<head>
	<title>Admin Shoe Store</title>
	<meta charset="utf-8">

    <!-- css -->
    <link rel="stylesheet" type="text/css" href="public_admin/css/style.css">
    <link rel="stylesheet" type="text/css" href="public_admin/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="public_admin/css/font-awesome.min.css">

    <script type="text/javascript" src="./views_admin/sanpham/ckeditor/ckeditor.js"></script>

</head>

<body>

<!-- Index này gọi view -->

     <?php
     require_once('layout/layout.php');
     ?>


     <?php
     require_once('dieuhuong.php');
     ?>

      <?php
     require_once('layout/footer.php');
     ?>

</body>
</html>
