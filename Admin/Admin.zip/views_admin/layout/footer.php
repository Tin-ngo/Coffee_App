<div class="footerr">
    
       <span class="pull-right"> Copyright &copy; Shoe Store 2020 </span>
 </div>