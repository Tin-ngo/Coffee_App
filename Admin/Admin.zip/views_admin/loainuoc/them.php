<div id="viewport">

<div class="container-fluid" id="noidung">
      <h4>Database loaisanpham</h4>

  
      <div style="background-color: #e5e5e5; padding: 10px 50px 10px; color:gray;">

        <form action="?action=themloainuoc" method="POST" enctype="multipart/form-data">
      	<table border="0" cellpadding="10">
         
            <tr>
               <td>Tên loại nước:</td>
               <td><input type="text" value="" name="tenLN" required></td>
           </tr>
            
           <tr>
           	<td colspan="2"><button  style="width: 100px; background-color: darkgray;" type="submit">Submit</button></td>
           </tr>

        </table>
      </form>
      </div>
     

</div>

</div>