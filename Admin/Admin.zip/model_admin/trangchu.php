<?php    
                                       // MODEL CHO CÁC THÔNG TIN SẢN PHẨM
    require_once('ketnoi.php');

    /**
     * 
     */
    class trangchu
    {
    	var $conn;
    	
    	function __construct()
    	{
    		$connect_obj = new ketnoi();
    		$this->conn = $connect_obj->connect;
    	}
    	
    	function all_nuoc()  
    	{
    		$query = "SELECT * FROM nuoc ORDER BY idNuoc";

    		$result = $this->conn->query($query);

    		$data = array();

    		while ($row = $result->fetch_assoc()) {
       		   $data[] = $row;
    		}

    		return $data;
    	}


        function all_loainuoc()  
        {
            $query = "SELECT * FROM loainuoc ORDER BY idLoaiNuoc";

            $result = $this->conn->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }

        function all_hoadon()  
        {
            $query = "SELECT * FROM hoadon ORDER BY idHoaDon";

            $result = $this->conn->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }

        function all_user()  
        {
            $query = "SELECT * FROM user ORDER BY idUser";

            $result = $this->conn->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }

        function all_khuyenmai()  
        {
            $query = "SELECT * FROM khuyenmai ORDER BY idKM";

            $result = $this->conn->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }

        function all_giathanh()  
        {
            $query = "SELECT * FROM giathanh";

            $result = $this->conn->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }


    }
     
?>