<?php    
                                       // MODEL CHO CÁC THÔNG TIN SẢN PHẨM
    require_once('ketnoi.php');

    /**
     * 
     */
    class API
    {
    	var $api;
    	
    	function __construct()
    	{
    		$connect_obj = new ketnoi();
            $this->api = $connect_obj->connect;
    	}

        function all_loainuoc()
        {
            
            $query = "SELECT * FROM loainuoc ORDER BY idloaiNuoc";

            $result = $this->api->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }

        function insert_loainuoc(){

            if(isset($_POST["tenLN"])){   // Thay bằng $_GET thì được

                // $tenLN = $_POST["tenLN"]
            $tenLN = filter_input(INPUT_POST, 'tenLN');  // Thay bằng INPUT_GET thì được

            $query = "INSERT INTO loainuoc(tenLN) VALUES ('$tenLN') ";

            $result = $this->api->query($query);

            if($result == true){
                $data[] = array(
                    'success'   =>  '1'
                );
            }
            else{
                $data[] = array(
                    'success'   =>  'lỗi'
                );
            }
            }else{
                $data[] = array(
                'success'   =>  'no value'
            );
        }
        return $data;

        }

        function all_user()   //r  - dùng để đăng nhập user
        {
            
            $query = "SELECT * FROM user ORDER BY idUser";

            $result = $this->api->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }



        function all_soban()  //đang
        {
            
            $query = "SELECT * FROM soban ORDER BY idSoban";

            $result = $this->api->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }




        // chưa
    	function all_nuoc()
    	{
            
    		$query = "SELECT * FROM nuoc ORDER BY idNuoc";

    		$result = $this->api->query($query);

    		$data = array();

    		while ($row = $result->fetch_assoc()) {
       		   $data[] = $row;
    		}

    		return $data;
    	}



// insert đặt bàn -- chưa xong
        function insert_datnuoc(){
            if(isset($_POST["idSoban"])){ 
                // $tenLN = $_POST["tenLN"]
            $idSoban = filter_input(INPUT_POST, 'idSoban');
            $idNuoc = filter_input(INPUT_POST, 'idNuoc');
            $soluong = filter_input(INPUT_POST, 'soluong');
            $ngay = filter_input(INPUT_POST, 'ngay');


            $query = "INSERT INTO datnuoc(idSoban, idNuoc, soluong, ngay) 
            VALUES ('$idSoban', '$idNuoc', '$soluong', '$ngay') ";

            $result = $this->api->query($query);

            if($result == true){
                $data[] = array(
                    'success'   =>  '1'
                );
            }
            else{
                $data[] = array(
                    'success'   =>  'lỗi'
                );
            }
            }else{
                $data[] = array(
                'success'   =>  'no value'
            );
        }
        return $data;
        }


    // xoá đặt nước
        function delete_datnuoc(){
            if(isset($_POST["idSoban"])){ 
                // $tenLN = $_POST["tenLN"]
            $idSoban = filter_input(INPUT_POST, 'idSoban');
            $idNuoc = filter_input(INPUT_POST, 'idNuoc');
            $soluong = filter_input(INPUT_POST, 'soluong');
            $ngay = filter_input(INPUT_POST, 'ngay');

            $query = "DELETE FROM datnuoc
             WHERE idSoban='$idSoban' && idNuoc = '$idNuoc' &&
              ngay = '$ngay' ";

            $result = $this->api->query($query);

            if($result == true){
                $data[] = array(
                    'success'   =>  '1'
                );
            }
            else{
                $data[] = array(
                    'success'   =>  'lỗi'
                );
            }
            }else{
                $data[] = array(
                'success'   =>  'no value'
            );
        }
        return $data;

        }
// xong delete


        function all_datnuoc_innerjoin()
        {
            
//             $query = "SELECT * FROM datnuoc ORDER BY idDatnuoc";
            $query = "SELECT * FROM datnuoc 
                    INNER JOIN soban 
                    INNER JOIN nuoc 
                    ON datnuoc.idSoban = soban.idSoban
                        && datnuoc.idNuoc = nuoc.idNuoc
                     ORDER BY Xong_Don
                    ";

            $result = $this->api->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }


                   
        function update_datnuoc_tt(){

            if(isset($_POST["thanhtoan"])){ 
                // $tenLN = $_POST["tenLN"]
            $thanhtoan = filter_input(INPUT_POST, 'thanhtoan');
            $idDatnuoc = filter_input(INPUT_POST, 'idDatnuoc');

            $query="UPDATE datnuoc SET thanhtoan = '$thanhtoan'
                     WHERE idDatnuoc='$idDatnuoc'";  

            $result = $this->api->query($query);

            if($result == true){
                $data[] = array(
                    'success'   =>  '1'
                );
            }
            else{
                $data[] = array(
                    'success'   =>  'lỗi'
                );
            }
            }else{
                $data[] = array(
                'success'   =>  'no value'
            );
        }
        return $data;
        }




// cập nhật nước đã bưng lên cho khách
        function update_xongnuoc(){

            if(isset($_POST["idDatnuoc"])){ 
                // $tenLN = $_POST["tenLN"]
            $Xong_Don = filter_input(INPUT_POST, 'Xong_Don');
            $idDatnuoc = filter_input(INPUT_POST, 'idDatnuoc');

            $query="UPDATE datnuoc SET Xong_Don = '$Xong_Don'
                     WHERE idDatnuoc='$idDatnuoc'";  

            $result = $this->api->query($query);

            if($result == true){
                $data[] = array(
                    'success'   =>  '1'
                );
            }
            else{
                $data[] = array(
                    'success'   =>  'lỗi'
                );
            }
            }else{
                $data[] = array(
                'success'   =>  'no value'
            );
        }
        return $data;
        }



// lấy inner join nuoc và giá thành theo id các loại nước đã đặt
        function all_nuoc_giathanh()
        {
            $query = "SELECT * FROM datnuoc 
                        INNER JOIN giathanh 
                        INNER JOIN nuoc
                        ON nuoc.idGiaThanh = giathanh.idGiaThanh && 
                        datnuoc.idNuoc = nuoc.idNuoc
                        ";

            $result = $this->api->query($query);

            $data = array();

            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }

            return $data;
        }



// lấy inner join nuoc và giá thành theo id các loại nước đã đặt hôm nay
        function loai_nuoc_giathanh_homnay()
        {
            $ngay = date("Y-m-d");
            $query="SELECT nuoc.tenNuoc, giathanh.GiaNiemYet FROM datnuoc 
                        INNER JOIN giathanh 
                        INNER JOIN nuoc
                        ON nuoc.idGiaThanh = giathanh.idGiaThanh && 
                        datnuoc.idNuoc = nuoc.idNuoc
                        WHERE datnuoc.ngay = '$ngay'
                        ";  
           $result = $this->api->query($query);
            $data = array();
            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }
            return $data;
        }



        function loai_nuoc_giathanh_thangnay()
        {
            $thang = date("Y-m");
            $query="SELECT nuoc.tenNuoc, giathanh.GiaNiemYet FROM datnuoc 
                        INNER JOIN giathanh 
                        INNER JOIN nuoc
                        ON nuoc.idGiaThanh = giathanh.idGiaThanh && 
                        datnuoc.idNuoc = nuoc.idNuoc
                        WHERE datnuoc.ngay LIKE '%$thang%'
                        ";  
           $result = $this->api->query($query);
            $data = array();
            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }
            return $data;
        }



        function loai_nuoc_giathanh_namnay()
        {
            $nam = date("Y");
            $query="SELECT nuoc.tenNuoc, giathanh.GiaNiemYet FROM datnuoc 
                        INNER JOIN giathanh 
                        INNER JOIN nuoc
                        ON nuoc.idGiaThanh = giathanh.idGiaThanh && 
                        datnuoc.idNuoc = nuoc.idNuoc
                        WHERE datnuoc.ngay LIKE '%$nam%'
                        ";  
           $result = $this->api->query($query);
            $data = array();
            while ($row = $result->fetch_assoc()) {
               $data[] = $row;
            }
            return $data;
        }


        

      

    }
     
?>